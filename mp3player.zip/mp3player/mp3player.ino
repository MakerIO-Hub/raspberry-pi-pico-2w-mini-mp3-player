#include <SPI.h>
#include <SD.h>
#include <Adafruit_GFX.h>
#include <Adafruit_ILI9341.h>
#include "AudioFileSourceSD.h"
#include "AudioGeneratorMP3.h"
#include "AudioOutputI2S.h"
#include <WiFi.h>
#include <HTTPClient.h>
#include <time.h>

// ==========================================
// WI-FI VE API AYARLARI
// ==========================================
static const char* WIFI_SSID   = "SUPERONLINE_Wi-Fi_3886_2.4GHZ";
static const char* WIFI_PASS   = "DRPRbYNEsQUk";
static const char* OWM_CITY    = "Istanbul,TR";
static const char* OWM_KEY     = "cff69c0dd777fa73518805a72bd697ce";
#define TZ_OFFSET_SEC           (3 * 3600)   // UTC+3 Türkiye
#define WIFI_RETRY_MS           10000UL      // 10sn'de bir bağlantı dene
#define NTP_RESYNC_MS           3600000UL    // Saatte bir NTP
#define OWM_UPDATE_MS           900000UL     // 15dk'da bir hava durumu
#define HTTP_TIMEOUT_MS         6000         // HTTP zaman aşımı

// ==========================================
// PIN TANIMLAMALARI
// ==========================================
#define TFT_CS   17
#define TFT_DC   14
#define TFT_RST  15
#define SD_CS    22
#define SPI_SCK  18
#define SPI_MOSI 19
#define SD_MISO  16
#define I2S_BCLK 0
#define I2S_LRC  1
#define I2S_DIN  2
#define BTN_PREV 6
#define BTN_PLAY 7
#define BTN_NEXT 8

// ==========================================
// RENKLER
// ==========================================
#define COLOR_BG     0x0825
#define COLOR_HEADER 0x03E0
#define COLOR_ACCENT ILI9341_CYAN
#define COLOR_TEXT   ILI9341_WHITE
#define COLOR_MUTED  ILI9341_LIGHTGREY

#define SCREENSAVER_TIMEOUT 30000UL

// ==========================================
// GLOBAL NESNELER
// ==========================================
Adafruit_ILI9341 tft = Adafruit_ILI9341(TFT_CS, TFT_DC, TFT_RST);
AudioFileSourceSD *audioFile = NULL;
AudioGeneratorMP3 *mp3       = NULL;
AudioOutputI2S    *i2sOut    = NULL;

// ==========================================
// PLAYLIST
// ==========================================
#define MAX_TRACKS 100
String playlist[MAX_TRACKS];
int trackCount        = 0;
int currentTrackIndex = 0;

// ==========================================
// DURUM DEĞİŞKENLERİ
// ==========================================
enum ScreenMode { PLAYER_MODE, SCREENSAVER_MODE };
ScreenMode currentMode = PLAYER_MODE;

bool  isPlaying   = false;
bool  trackLoaded = false;
float volume      = 0.5f;

uint32_t lastUserAction    = 0;
uint32_t lastDisplayUpdate = 0;

// Buton state
bool playWasPressed = false;  uint32_t playPressTime  = 0;
bool prevWasPressed = false;  uint32_t prevPressStart = 0;  bool prevLongDone = false;
bool nextWasPressed = false;  uint32_t nextPressStart = 0;  bool nextLongDone = false;

// ==========================================
// WI-FI STATE MACHINE (non-blocking)
// ==========================================
enum WiFiState { WIFI_IDLE, WIFI_CONNECTING, WIFI_CONNECTED, WIFI_FAILED };
WiFiState wifiState       = WIFI_IDLE;
uint32_t  wifiRetryTime   = 0;
uint32_t  wifiConnectStart = 0;
bool      timeSynced      = false;
uint32_t  lastNTPSync     = 0;

// Hava durumu
bool     weatherReady    = false;
int      weatherTemp     = 0;
int      weatherHumidity = 0;
char     weatherDesc[32] = "--";
uint32_t lastOWMUpdate   = 0;

// ==========================================
// FONKSİYON PROTOTİPLERİ
// ==========================================
void setupDisplay();
void setupSD();
void setupAudio();
void setupButtons();
void scanRootDirectory();

void loadTrack(int index);
void startPlay();
void pausePlay();
void resumePlay();
void stopPlay();
void nextTrack();
void previousTrack();
void audioTask();

void handleWiFi();
void syncNTP();
void fetchWeather();

void drawPlayerFull();
void drawPlayerDynamic();
void drawScreensaverFull();
void drawScreensaverUpdate();

void checkButtons();
void checkScreensaver();

// ==========================================
// SETUP
// ==========================================
void setup() {
  Serial.begin(115200);

  setupDisplay();

  tft.fillScreen(COLOR_BG);
  tft.setTextColor(COLOR_ACCENT); tft.setTextSize(3);
  tft.setCursor(20, 75); tft.print("PICO 2 W");
  tft.setTextColor(COLOR_TEXT); tft.setTextSize(2);
  tft.setCursor(20, 115); tft.print("MINI MP3 PLAYER");
  delay(1200);

  tft.fillRect(0, 155, 320, 50, COLOR_BG);
  tft.setTextColor(ILI9341_YELLOW); tft.setCursor(20, 160);
  tft.print("Initializing...");

  setupSD();
  setupAudio();
  setupButtons();
  scanRootDirectory();

  // WiFi başlat (non-blocking)
  WiFi.mode(WIFI_STA);
  WiFi.begin(WIFI_SSID, WIFI_PASS);
  wifiState       = WIFI_CONNECTING;
  wifiConnectStart = millis();
  Serial.println("WiFi: Connecting...");

  lastUserAction = millis();

  if (trackCount > 0) {
    tft.fillRect(0, 155, 320, 50, COLOR_BG);
    tft.setTextColor(ILI9341_GREEN); tft.setCursor(20, 160);
    tft.print(trackCount); tft.print(" MP3 FOUND");
    delay(800);
    drawPlayerFull();
  } else {
    tft.fillRect(0, 155, 320, 50, COLOR_BG);
    tft.setTextColor(ILI9341_RED); tft.setCursor(20, 160);
    tft.print("NO MP3 FOUND!");
  }
}

// ==========================================
// LOOP — Her şey burada, non-blocking
// ==========================================
void loop() {
  audioTask();       // Müzik her zaman öncelikli
  handleWiFi();      // WiFi state machine
  checkScreensaver();
  checkButtons();

  if (currentMode == PLAYER_MODE) {
    if (millis() - lastDisplayUpdate > 400) {
      drawPlayerDynamic();
      lastDisplayUpdate = millis();
    }
  } else {
    if (millis() - lastDisplayUpdate > 1000) {
      drawScreensaverUpdate();
      lastDisplayUpdate = millis();
    }
  }
}

// ==========================================
// WI-FI STATE MACHINE (non-blocking)
// ==========================================
void handleWiFi() {
  uint32_t now = millis();

  switch (wifiState) {

    case WIFI_CONNECTING:
      if (WiFi.status() == WL_CONNECTED) {
        wifiState = WIFI_CONNECTED;
        Serial.println("WiFi: Connected!");
        syncNTP();
        lastOWMUpdate = 0; // hemen çeksin
      } else if (now - wifiConnectStart > 15000) {
        // 15 saniye içinde bağlanamazsa
        wifiState    = WIFI_FAILED;
        wifiRetryTime = now;
        Serial.println("WiFi: Timeout, will retry.");
      }
      break;

    case WIFI_CONNECTED:
      // Bağlantı koptu mu?
      if (WiFi.status() != WL_CONNECTED) {
        wifiState     = WIFI_FAILED;
        wifiRetryTime = now;
        Serial.println("WiFi: Lost connection.");
        break;
      }

      // NTP yenile
      if (!timeSynced || (now - lastNTPSync > NTP_RESYNC_MS)) {
        syncNTP();
      }

      // Hava durumu güncelle
      if (now - lastOWMUpdate > OWM_UPDATE_MS || lastOWMUpdate == 0) {
        fetchWeather();
        lastOWMUpdate = now;
      }
      break;

    case WIFI_FAILED:
      if (now - wifiRetryTime > WIFI_RETRY_MS) {
        Serial.println("WiFi: Retrying...");
        WiFi.disconnect();
        delay(100);
        WiFi.begin(WIFI_SSID, WIFI_PASS);
        wifiState        = WIFI_CONNECTING;
        wifiConnectStart = now;
      }
      break;

    default:
      break;
  }
}

// ==========================================
// NTP SENKRONU
// ==========================================
void syncNTP() {
  configTime(TZ_OFFSET_SEC, 0, "pool.ntp.org", "time.nist.gov");
  // configTime non-blocking; zamanın gelmesini beklemiyoruz
  // Bir sonraki loop iterasyonunda time() geçerli değeri verir
  lastNTPSync = millis();

  // Kısa poll — audio kesilmemesi için max 200ms bekle
  uint32_t t0 = millis();
  while (millis() - t0 < 200) {
    time_t now = time(nullptr);
    if (now > 1700000000UL) { timeSynced = true; break; }
    delay(20);
  }
  if (timeSynced) Serial.println("NTP: Synced.");
  else            Serial.println("NTP: Waiting...");
}

// ==========================================
// HAVA DURUMU ÇEK
// ==========================================
void fetchWeather() {
  // Bu fonksiyon en fazla HTTP_TIMEOUT_MS kadar bloke olabilir
  // Müzik bu sürede kısaca durabilir — kabul edilebilir (6sn içinde tamamlanır)
  
  // HTTP isteği öncesi mp3 loop'unu bir kaç kez çağır
  if (mp3 && mp3->isRunning() && isPlaying) mp3->loop();

  String url = "http://api.openweathermap.org/data/2.5/weather?q=";
  url += OWM_CITY;
  url += "&appid="; url += OWM_KEY;
  url += "&units=metric";

  HTTPClient http;
  http.begin(url);
  http.setTimeout(HTTP_TIMEOUT_MS);
  int code = http.GET();

  if (code == HTTP_CODE_OK) {
    String body = http.getString();

    // Sıcaklık
    int ti = body.indexOf("\"temp\":");
    if (ti > 0) {
      float t = body.substring(ti + 7, body.indexOf(',', ti)).toFloat();
      weatherTemp = (int)(t + 0.5f);
    }

    // Nem
    int hi = body.indexOf("\"humidity\":");
    if (hi > 0) {
      weatherHumidity = body.substring(hi + 11, body.indexOf(',', hi)).toInt();
    }

    // Açıklama
    int wi = body.indexOf("\"weather\":[");
    int mi = (wi > 0) ? body.indexOf("\"main\":\"", wi) : -1;
    if (mi > 0) {
      int s = mi + 8;
      String d = body.substring(s, body.indexOf('"', s));
      d.toCharArray(weatherDesc, sizeof(weatherDesc));
      weatherReady = true;
    }
    Serial.print("Weather: "); Serial.print(weatherTemp);
    Serial.print("C, "); Serial.println(weatherDesc);
  } else {
    Serial.print("Weather HTTP error: "); Serial.println(code);
  }
  http.end();
}

// ==========================================
// DONANIM KURULUM
// ==========================================
void setupDisplay() {
  SPI.setRX(SD_MISO); SPI.setTX(SPI_MOSI); SPI.setSCK(SPI_SCK);
  SPI.begin();
  pinMode(TFT_CS, OUTPUT); pinMode(SD_CS, OUTPUT);
  digitalWrite(TFT_CS, HIGH); digitalWrite(SD_CS, HIGH);
  tft.begin(); tft.setRotation(3);
}

void setupSD() {
  if (!SD.begin(SD_CS, SPI)) {
    tft.fillRect(0, 155, 320, 45, COLOR_BG);
    tft.setTextColor(ILI9341_RED); tft.setCursor(20, 160);
    tft.print("SD CARD ERROR!"); while (1);
  }
}

void setupAudio() {
  i2sOut = new AudioOutputI2S();
  i2sOut->SetPinout(I2S_BCLK, I2S_LRC, I2S_DIN);
  i2sOut->SetGain(volume);
  mp3 = new AudioGeneratorMP3();
}

void setupButtons() {
  pinMode(BTN_PREV, INPUT_PULLUP);
  pinMode(BTN_PLAY, INPUT_PULLUP);
  pinMode(BTN_NEXT, INPUT_PULLUP);
}

// ==========================================
// SD TARAMA
// ==========================================
void scanRootDirectory() {
  trackCount = 0;
  File root = SD.open("/");
  if (!root) return;
  while (true) {
    File entry = root.openNextFile();
    if (!entry) break;
    if (!entry.isDirectory()) {
      String name = String(entry.name());
      String lower = name; lower.toLowerCase();
      if (lower.endsWith(".mp3") && trackCount < MAX_TRACKS)
        playlist[trackCount++] = name;
    }
    entry.close();
  }
  root.close();
}

// ==========================================
// SES FONKSİYONLARI
// ==========================================
void loadTrack(int index) {
  if (mp3 && mp3->isRunning()) mp3->stop();
  if (audioFile) { audioFile->close(); delete audioFile; audioFile = NULL; }
  String path = "/" + playlist[index];
  audioFile  = new AudioFileSourceSD(path.c_str());
  trackLoaded = (audioFile != NULL);
  isPlaying   = false;
}

void startPlay()  { if (trackLoaded && audioFile && mp3->begin(audioFile, i2sOut)) isPlaying = true; }
void pausePlay()  { isPlaying = false; }
void resumePlay() { if (trackLoaded && audioFile) isPlaying = true; }

void stopPlay() {
  if (mp3 && mp3->isRunning()) mp3->stop();
  if (audioFile) { audioFile->close(); delete audioFile; audioFile = NULL; }
  isPlaying = trackLoaded = false;
}

void nextTrack() {
  currentTrackIndex = (currentTrackIndex + 1) % trackCount;
  loadTrack(currentTrackIndex); startPlay();
  if (currentMode == PLAYER_MODE) drawPlayerFull();
}

void previousTrack() {
  currentTrackIndex = (currentTrackIndex - 1 + trackCount) % trackCount;
  loadTrack(currentTrackIndex); startPlay();
  if (currentMode == PLAYER_MODE) drawPlayerFull();
}

void audioTask() {
  if (!isPlaying || !mp3 || !mp3->isRunning()) return;
  if (!mp3->loop()) {
    mp3->stop();
    if (audioFile) { audioFile->close(); delete audioFile; audioFile = NULL; }
    isPlaying = trackLoaded = false;
    currentTrackIndex = (currentTrackIndex + 1) % trackCount;
    loadTrack(currentTrackIndex); startPlay();
    if (currentMode == PLAYER_MODE) drawPlayerFull();
  }
}

// ==========================================
// SCREENSAVER KONTROL
// ==========================================
void checkScreensaver() {
  if (currentMode == PLAYER_MODE &&
      millis() - lastUserAction > SCREENSAVER_TIMEOUT) {
    currentMode = SCREENSAVER_MODE;
    tft.fillScreen(ILI9341_BLACK);
    drawScreensaverFull();
    lastDisplayUpdate = millis();
  }
}

// ==========================================
// BUTON KONTROL
// ==========================================
void checkButtons() {
  uint32_t now = millis();
  bool prevP = (digitalRead(BTN_PREV) == LOW);
  bool playP = (digitalRead(BTN_PLAY) == LOW);
  bool nextP = (digitalRead(BTN_NEXT) == LOW);
  bool any   = prevP || playP || nextP;

  if (currentMode == SCREENSAVER_MODE && any) {
    lastUserAction = now;
    currentMode    = PLAYER_MODE;
    tft.fillScreen(COLOR_BG);
    drawPlayerFull();
    lastDisplayUpdate = millis();
    if (prevP) { prevWasPressed = true; prevPressStart = now; prevLongDone = true; }
    if (playP) { playWasPressed = true; playPressTime  = now; }
    if (nextP) { nextWasPressed = true; nextPressStart = now; nextLongDone = true; }
    return;
  }
  if (currentMode != PLAYER_MODE) return;

  // PLAY / PAUSE
  if (playP && !playWasPressed && (now - playPressTime > 250)) {
    lastUserAction = now;
    if (isPlaying) {
      pausePlay();
    } else {
      if (!trackLoaded) { loadTrack(currentTrackIndex); startPlay(); drawPlayerFull(); }
      else resumePlay();
    }
    drawPlayerDynamic();
    playWasPressed = true; playPressTime = now;
  } else if (!playP) { playWasPressed = false; }

  // PREV — Kısa: Önceki | Uzun: Ses Aç (+)
  if (prevP) {
    if (!prevWasPressed) { prevPressStart = now; prevWasPressed = true; prevLongDone = false; }
    else if (now - prevPressStart > 500) {
      static uint32_t lv = 0;
      if (now - lv > 120) {
        volume = min(1.0f, volume + 0.05f);
        i2sOut->SetGain(volume); drawPlayerDynamic();
        lv = now; prevLongDone = true; lastUserAction = now;
      }
    }
  } else {
    if (prevWasPressed) {
      if (!prevLongDone && now - prevPressStart > 50) { lastUserAction = now; previousTrack(); }
      prevWasPressed = false;
    }
  }

  // NEXT — Kısa: Sonraki | Uzun: Ses Kıs (-)
  if (nextP) {
    if (!nextWasPressed) { nextPressStart = now; nextWasPressed = true; nextLongDone = false; }
    else if (now - nextPressStart > 500) {
      static uint32_t lv2 = 0;
      if (now - lv2 > 120) {
        volume = max(0.0f, volume - 0.05f);
        i2sOut->SetGain(volume); drawPlayerDynamic();
        lv2 = now; nextLongDone = true; lastUserAction = now;
      }
    }
  } else {
    if (nextWasPressed) {
      if (!nextLongDone && now - nextPressStart > 50) { lastUserAction = now; nextTrack(); }
      nextWasPressed = false;
    }
  }
}

// ==========================================
// PLAYER EKRANI — TAM
// ==========================================
void drawPlayerFull() {
  tft.fillScreen(COLOR_BG);
  tft.fillRect(0, 0, 320, 36, COLOR_HEADER);
  tft.setTextColor(COLOR_TEXT); tft.setTextSize(2);
  tft.setCursor(15, 10); tft.print("Mini MP3 Player");
  tft.fillRect(20, 55, 80, 80, ILI9341_DARKCYAN);
  tft.drawRect(20, 55, 80, 80, COLOR_TEXT);
  tft.setTextColor(COLOR_TEXT); tft.setTextSize(4);
  tft.setCursor(45, 80); tft.print("M");
  tft.fillRect(0, 190, 320, 50, COLOR_HEADER);
  tft.setTextColor(COLOR_MUTED); tft.setTextSize(2);
  tft.setCursor(20, 205); tft.print("PREV");
  tft.setCursor(250, 205); tft.print("NEXT");
  drawPlayerDynamic();
}

// ==========================================
// PLAYER EKRANI — DEĞİŞEN ALANLAR
// ==========================================
void drawPlayerDynamic() {
  tft.fillRect(115, 55, 195, 28, COLOR_BG);
  tft.setTextColor(ILI9341_YELLOW); tft.setTextSize(2);
  tft.setCursor(115, 60);
  String tName = (trackCount > 0) ? playlist[currentTrackIndex] : "--";
  if (tName.length() > 14) tName = tName.substring(0, 13) + "~";
  tft.print(tName);

  tft.fillRect(115, 88, 195, 18, COLOR_BG);
  tft.setTextColor(COLOR_MUTED); tft.setTextSize(1);
  tft.setCursor(115, 91);
  tft.print("Track "); tft.print(currentTrackIndex + 1);
  tft.print(" / "); tft.print(trackCount);

  tft.fillRect(115, 108, 195, 18, COLOR_BG);
  tft.setTextSize(1); tft.setCursor(115, 111);
  if (isPlaying) { tft.setTextColor(ILI9341_GREEN); tft.print("PLAYING..."); }
  else           { tft.setTextColor(ILI9341_RED);   tft.print("PAUSED"); }

  tft.fillRect(215, 8, 100, 20, COLOR_HEADER);
  tft.setTextSize(1); tft.setTextColor(COLOR_ACCENT);
  tft.setCursor(220, 13);
  tft.print("VOL:"); tft.print((int)(volume * 100)); tft.print("%");

  // WiFi durum ikonu (header sağ alt köşe)
  tft.fillRect(295, 22, 20, 12, COLOR_HEADER);
  tft.setTextSize(1);
  tft.setTextColor(wifiState == WIFI_CONNECTED ? ILI9341_GREEN : ILI9341_RED);
  tft.setCursor(296, 24);
  tft.print(wifiState == WIFI_CONNECTED ? "W" : "x");

  tft.fillRect(108, 195, 104, 40, COLOR_HEADER);
  tft.setTextColor(COLOR_TEXT); tft.setTextSize(2);
  tft.setCursor(118, 205);
  tft.print(isPlaying ? "PAUSE" : " PLAY");

  tft.drawRect(20, 148, 280, 14, COLOR_MUTED);
  if (audioFile && trackLoaded) {
    uint32_t pos  = audioFile->getPos();
    uint32_t size = audioFile->getSize();
    if (size > 0) {
      int pw = (int)((float)pos / size * 278.0f);
      tft.fillRect(21, 149, pw,       12, COLOR_ACCENT);
      tft.fillRect(21 + pw, 149, 278 - pw, 12, COLOR_BG);
    }
  } else {
    tft.fillRect(21, 149, 278, 12, COLOR_BG);
  }
}

// ==========================================
// SCREENSAVER — TAM ÇİZİM
// ==========================================
void drawScreensaverFull() {
  tft.fillScreen(ILI9341_BLACK);
  tft.drawRect(0, 0, 320, 240, 0x4228);
  drawScreensaverUpdate();
}

// ==========================================
// SCREENSAVER — GÜNCELLEME (saniyede bir)
// ==========================================
void drawScreensaverUpdate() {
  // Saat
  tft.fillRect(55, 15, 210, 56, ILI9341_BLACK);
  tft.setTextColor(ILI9341_WHITE); tft.setTextSize(5);
  char clk[6];
  if (timeSynced) {
    time_t n = time(nullptr); struct tm* ti = localtime(&n);
    if (millis() % 2000 < 1000) sprintf(clk, "%02d:%02d", ti->tm_hour, ti->tm_min);
    else                         sprintf(clk, "%02d %02d", ti->tm_hour, ti->tm_min);
  } else {
    strcpy(clk, "--:--");
  }
  tft.setCursor(80, 18); tft.print(clk);

  // Tarih
  tft.fillRect(5, 80, 310, 22, ILI9341_BLACK);
  tft.setTextColor(ILI9341_CYAN); tft.setTextSize(2);
  if (timeSynced) {
    time_t n = time(nullptr); struct tm* ti = localtime(&n);
    char ds[32]; strftime(ds, sizeof(ds), "%d %B %Y", ti);
    int dx = (320 - (int)(strlen(ds) * 12)) / 2;
    tft.setCursor(dx, 82); tft.print(ds);
  } else {
    tft.setCursor(55, 82); tft.print("Connecting...");
  }

  // Hava durumu
  tft.fillRect(5, 112, 310, 78, ILI9341_BLACK);
  if (weatherReady) {
    char ts[12]; sprintf(ts, "%d C", weatherTemp);
    tft.setTextColor(ILI9341_YELLOW); tft.setTextSize(3);
    tft.setCursor((320 - (int)(strlen(ts) * 18)) / 2, 115);
    tft.print(ts);

    tft.setTextColor(ILI9341_WHITE); tft.setTextSize(2);
    tft.setCursor((320 - (int)(strlen(weatherDesc) * 12)) / 2, 148);
    tft.print(weatherDesc);

    char hs[20]; sprintf(hs, "Humidity %d%%", weatherHumidity);
    tft.setTextColor(COLOR_MUTED); tft.setTextSize(1);
    tft.setCursor((320 - (int)(strlen(hs) * 6)) / 2, 173);
    tft.print(hs);
  } else {
    tft.setTextColor(COLOR_MUTED); tft.setTextSize(1);
    tft.setCursor(90, 140); tft.print("Weather Unavailable");
  }

  // Çalan şarkı
  tft.fillRect(5, 196, 310, 16, ILI9341_BLACK);
  if (trackCount > 0) {
    String sn = playlist[currentTrackIndex];
    if (sn.length() > 32) sn = sn.substring(0, 31) + "~";
    tft.setTextColor(0x7BEF); tft.setTextSize(1);
    tft.setCursor((320 - (int)((sn.length() + 2) * 6)) / 2, 197);
    tft.print("~ "); tft.print(sn);
  }

  // Alt uyarı
  tft.fillRect(5, 218, 310, 14, ILI9341_BLACK);
  tft.setTextColor(ILI9341_DARKGREY); tft.setTextSize(1);
  tft.setCursor(65, 220); tft.print("PRESS ANY BUTTON TO WAKE");
}